All of the files contained in this directory and any subdirectories are 
considered "Sample Code" under the terms of the end user license agreement 
that accompanies this product. Please consult such end user license agreement 
for details about your rights with respect to such files.
